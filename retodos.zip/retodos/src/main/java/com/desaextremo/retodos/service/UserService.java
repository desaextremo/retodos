package com.desaextremo.retodos.service;

import com.desaextremo.retodos.entity.User;
import com.desaextremo.retodos.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {
    @Autowired
    private UserRepository repositorio;

    public List<User> getAll(){
        return repositorio.findAll();
    }

    public User getUser(Integer id) {
        Optional<User> optional = repositorio.findById(id);

        if (optional.isPresent()) return optional.get();
        else return new User();
    }

    public boolean existeEmail(String email){
        Optional<User> optional =  repositorio.findByEmail(email);

        if (optional.isPresent()) return true;
        else return false;
    }

    public User autenticarUsuario(String email, String password){
        Optional<User> optional =  repositorio.findByEmailAndPassword(email,password);
        if (optional.isPresent()) return optional.get();
        else return new User();
    }

    public User registrar(User user) {
        User userError;

        if (user.getId() != null) {
            if (existeEmail(user.getEmail()) == false) {
                return repositorio.save(user);
            } else {
                userError = new User();
                userError.setName("CORREO EXISTE");
                return userError;
            }
        } else {
            userError = new User();
            userError.setName("FALTA EL ID");
            return userError;
        }
    }

    public User actualizar(User user) {
        User userDb;
        if (user.getId() != null) {
            Optional<User> optional = repositorio.findById(user.getId());
            if (optional.isPresent()) {

                userDb = optional.get();
                if (user.getIdentification() != null) {
                    if (!userDb.getIdentification().equals(user.getIdentification()))   userDb.setIdentification(user.getIdentification());
                }
                if (user.getName() != null) {
                    if (!userDb.getName().equals(user.getName()))  userDb.setName(user.getName());
                }
                if (user.getAddress() != null) {
                    if (!userDb.getAddress().equals(user.getAddress())) userDb.setAddress(user.getAddress());
                }
                if (user.getCellPhone() != null) {
                    if (!userDb.getCellPhone().equals(user.getCellPhone()))userDb.setCellPhone(user.getCellPhone());
                }
                if (user.getEmail() != null) {
                    if (!userDb.getEmail().equals(user.getEmail())) userDb.setEmail(user.getEmail());
                }
                if (user.getPassword() != null) {
                    if (!userDb.getPassword().equals(user.getPassword())) userDb.setPassword(user.getPassword());
                }
                if (user.getZone() != null) {
                    if (!userDb.getZone().equals(user.getZone())) userDb.setZone(user.getZone());
                }

                return repositorio.save(userDb);
            } else {
                return user;
            }
        } else {
            return user;
        }
    }

    public boolean delete(int id) {
        User userDelete;
        Optional<User> optional = repositorio.findById(id);

        if (optional.isPresent()){
            userDelete = optional.get();
            repositorio.delete(userDelete);
            return true;
        }else{
            return false;
        }
    }
}
