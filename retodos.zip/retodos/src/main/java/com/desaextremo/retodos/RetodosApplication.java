package com.desaextremo.retodos;

import com.desaextremo.retodos.entity.User;
import com.desaextremo.retodos.repository.UserRepository;
import com.desaextremo.retodos.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

@SpringBootApplication
public class RetodosApplication implements CommandLineRunner {
	//atributos de relacion
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private UserService userService;

	public static void main(String[] args) {
		SpringApplication.run(RetodosApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		//borrar documentos en la coleccion
		userRepository.deleteAll();
		//formato de fechas
		SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");
		//insertar documentos en la coleccion de usuarios

		userRepository.saveAll(List.of(
				new User(1, "123123", "ALAN BRITO","CR 34-45", "311222222", "abrito@gmail.com", "Demo123.", "ZONA 2", "ADM"),
                new User(2, "61123211", "NAPOLEON BONAPARTE","CR 34-45", "3168965645", "nbonaparte@gmail.com", "Demo123.", "ZONA 2", "COORD"),
                new User(3, "46669989", "BLODY MARRY","CR 34-45", "3174565625", "stellez@gmail.com", "Demo123.", "ZONA 2", "ASE"),
                new User(4, "52369563", "JUANA DE ARCO","CR 34-45", "3265632", "jdarco@gmail.com", "Demo123.", "ZONA 2", "ASE"),
                new User(5, "123456789", "ALCIRA LA ALPACA","CR 34-45", "3168965645", "aalpaca@gmail.com", "Demo123.", "ZONA 1", "COORD"),
                new User(6, "213456789", "PEDRO CAPAROSA", "CR 34-45", "3168965645", "pcaparosa@gmail.com", "Demo123.", "ZONA 1", "ASE"),
                new User(7, "312456789", "LUIS IXV UN SOL","CR 34-45", "3168965645", "reysol@gmail.com", "Demo123.", "ZONA 1", "ASE")
		));

		//listar usuarios
		/*
		List<User> usuarios = userRepository.findAll();

		System.out.println("Listado de usuarios");
		System.out.println("-----------------------------");
		for (User usuario:usuarios) {
			System.out.println(usuario.toString());
		}


		//validar existencia de email
		Optional<User> optional =  userRepository.findByEmail("jdarco@gmail.com");

		if (optional.isPresent()){
			User usuario = optional.get();
			System.out.println("El usuario existe");
			System.out.println(usuario.toString());
		}else{
			System.out.println("No existe usuario asociado al email");
		}

		//autenticacion
		//validar existencia de email
		optional =  userRepository.findByEmailAndPassword("jdarco@gmail.com","Demo12");

		if (optional.isPresent()){
			User usuario = optional.get();
			System.out.println("Usuario AUTENTICADO");
			System.out.println(usuario.toString());
		}else{
			System.out.println("No existe usuario asociado al email/PASSWORD");
		}


		//caso de exito
		boolean existe;

		existe = userService.existeEmail("abrito@gmail.com");

		if (existe) System.out.println("Existe un usuario asociado al email: abrito@gmail.com");
		else System.out.println("NO Existe un usuario asociado al email: abrito@gmail.com");

		//caso de fallido
		existe = userService.existeEmail("abri@gmail.com");
		if (existe) System.out.println("Existe un usuario asociado al email: abri@gmail.com");
		else System.out.println("NO Existe un usuario asociado al email: abri@gmail.com");

		//caso de exito
		User usuario;

		usuario = userService.autenticarUsuario("abrito@gmail.com","Demo123.");

		System.out.println("Datos del usuario");
		System.out.println(usuario.toString());

		//caso de fallido
		usuario = userService.autenticarUsuario("abri@gmail.com","Demo123.");
		System.out.println("Datos del usuario");
		System.out.println(usuario.toString());

		System.out.println("Datos del usuario: \n" + userService.getUser(1));
		System.out.println("Datos del usuario: \n" + userService.getUser(55));
 		*/
	}
}
