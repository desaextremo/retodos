//https://www.tutorialspoint.com/How-to-add-rows-to-a-table-using-JavaScript-DOM

const tarea = document.querySelector("#tarea");
const boton = document.querySelector("#boton");
const botonDos = document.querySelector("#botonDos");
const filas = document.querySelector("#filas");
let contadorFilas=0;
tarea.focus()

boton.addEventListener("click",agregarTarea);
//botonDos.addEventListener("click",agregarTareaDos);


function agregarTarea(){
    contadorFilas++;
    let nombreTarea = tarea.value;

    //crear los elementos
    
    //crear texto
    var textoColumna = document.createTextNode(nombreTarea);

    //crear fila
    let fila = document.createElement("tr");
    let columna = document.createElement("td");
    let columnaBoton = document.createElement("td");
    let botonBorrar = document.createElement("button");
    let id = "id"+contadorFilas

    fila.setAttribute("id",id);
    botonBorrar.innerHTML="Aceptar";
    botonBorrar.setAttribute("onclick", `doTask(${id})`);
    //botonBorrar.addEventListener('click', doTask);
    
    

    //columna.innerHTML=nombreTarea
    columna.appendChild(textoColumna);
    columnaBoton.appendChild(botonBorrar);
    fila.appendChild(columna);
    fila.appendChild(columnaBoton);
    filas.appendChild(fila);
    tarea.value="";
    tarea.focus();
}

function doTask(id){
    
    id.remove();
    alert(" Elemento eliminado");
}
/*
function agregarTareaDos(){
    let nombreTarea = tarea.value;

    let row = filas.insertRow(-1); // We are adding at the end
   
    // Create table cells
    let c1 = row.insertCell(0);
    c1.innerText = nombreTarea;
    tarea.value="";
    tarea.focus();
}
*/